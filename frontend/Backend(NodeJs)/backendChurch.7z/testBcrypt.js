import bcrypt from 'bcryptjs';

console.log('bcrypt:', bcrypt);
// const bcrypt = require('bcryptjs');
// console.log('bcrypt:', bcrypt);
