import express from 'express';
import { addEvent, fetchAllEvent,  detailEvent, updateEvent, deleteEvent, countAllEvents} from '../controller/eventController.js';

const routerEvent = express.Router();

// Event Routes
routerEvent.post('/add', addEvent);         
routerEvent.get('/fetchAll/:churchId?', fetchAllEvent);
           
routerEvent.get('/detail/:id', detailEvent);        
routerEvent.patch('/edit/:id', updateEvent);  
routerEvent.get('/count', countAllEvents);   

routerEvent.delete('/delete/:id', deleteEvent);  

export default routerEvent;
