import Event from '../model/eventModel.js';

export const addEvent = async (req, res) => {
  try {
    const { name, date, description, churchId } = req.body;

    // Check if the Event already exists
    const existingEvent = await Event.findOne({ name, churchId });
    if (existingEvent) {
      return res.status(400).json({ error: 'Event already exists for this church' });
    }

    const newEvent = new Event({ name, date, description, churchId });

    // Save the Event to the database
    await newEvent.save();

    res.status(201).json({ message: 'Event saved successfully', event: newEvent });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const fetchAllEvent = async (req, res) => {
  try {
    const { churchId } = req.params;

    // If churchId exists, filter by it; otherwise, return all events
    const query = churchId ? { churchId } : {}; 

    const events = await Event.find(query);
    
    console.log(events);
    res.status(200).json(events);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};


// export const fetchAllEvent = async (req, res) => {
//   try {
//     const { churchId } = req.params; // Assume churchId is sent as a URL parameter
//     const events = await Event.find({ churchId });

//     // If no events are found, `events` will be an empty array, and it will return with a 200 status.
//     console.log(events);
//     res.status(200).json(events);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// };


  // Add this function to your Event controller
  // export const countAllEvents = async (req, res) => {
  //   try {
  //     const count = await Event.countDocuments(); // Count all Eventes
  //     res.status(200).json({ total: count }); // Return the total count in the response
  //   } catch (error) {
  //     res.status(500).json({ error: error.message }); // Handle errors
  //   }
  // };


  export const countAllEvents = async (req, res) => {
    try {
      const { churchId } = req.query; // Get churchId from query parameters
  
      const count = churchId
        ? await Event.countDocuments({ churchId }) // Count events for specific churchId
        : await Event.countDocuments(); // Count all events if no churchId is specified
  
      res.status(200).json({ total: count });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  };
  


export const fetchEventType = async (req, res) => {
  try {
    const { type, churchId } = req.params; // Assuming type and churchId are URL parameters
    const events = await Event.find({ type, churchId });
    res.status(200).json(events);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
  

  
export const detailEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const eventDetail = await Event.findOne({ _id: id});
    if (!eventDetail) {
      return res.status(404).json({ error: 'Event not found' });
    }
    res.status(200).json(eventDetail);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
  
  
export const updateEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const updateFields = req.body;

    const updatedEvent = await Event.findOneAndUpdate(
      { _id: id },
      { $set: updateFields },
      { new: true }
    );

    if (!updatedEvent) {
      return res.status(404).json({ error: 'Event not found' });
    }

    res.status(200).json({ message: 'Event updated successfully', event: updatedEvent });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};



  // Delete Event by ID
  export const deleteEvent = async (req, res) => {
    try {
      const { id } = req.params;
      const deletedEvent = await Event.findOneAndDelete({ _id: id });
  
      if (!deletedEvent) {
        return res.status(404).json({ error: 'Event not found' });
      }
  
      res.status(200).json({ message: 'Event deleted successfully' });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  };
  

  
