import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import { connectToDB } from './db.js';
import router from './route/authRoute.js'; 
import routerChurch from './route/churchRoute.js'; 
import routerUser from './route/userRoute.js'; 
import routerUserWeb from './route/userWebRoute.js'; 
import routerEvent from './route/eventRoute.js'; 



import path from 'path';
import { fileURLToPath } from 'url';
const app = express();
dotenv.config();

app.use(cors());
app.use(express.json()); 

// Use import.meta.url and fileURLToPath to get __dirname equivalent
app.use(express.json({ limit: '500mb' }));
app.use(express.urlencoded({ limit: '500mb', extended: true }));
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/churchProfile', express.static(path.join(__dirname, 'churchProfile')));
app.use('/api/auth', router); 
app.use('/api/church', routerChurch); 
app.use('/api/user', routerUser); 
app.use('/api', routerUserWeb); 
app.use('/api/event', routerEvent); 


const PORT = process.env.PORT || 5500;

connectToDB()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server started at: http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.log(err);
  });
